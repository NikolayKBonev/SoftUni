package christmaspastryshop.common.enums;

public enum CocktailType {
    MulledWine,
    Hibernation
}
