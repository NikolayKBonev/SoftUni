package christmaspastryshop.common.enums;

public enum BoothType {
    OpenBooth,
    PrivateBooth
}
