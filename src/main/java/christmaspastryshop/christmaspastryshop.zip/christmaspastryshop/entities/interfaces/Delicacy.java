package christmaspastryshop.entities.interfaces;

public interface Delicacy {
    String getName();
    double getPortion();
    double getPrice();
}
