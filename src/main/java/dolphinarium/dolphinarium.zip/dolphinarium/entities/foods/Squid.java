// Squid.java
package dolphinarium.entities.foods;

public class Squid extends BaseFood {
    private static final int CALORIES = 175;

    public Squid() {
        super(CALORIES);
    }
}
