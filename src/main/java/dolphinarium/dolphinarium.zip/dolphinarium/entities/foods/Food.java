package dolphinarium.entities.foods;

public interface Food {
    int getCalories();
}
