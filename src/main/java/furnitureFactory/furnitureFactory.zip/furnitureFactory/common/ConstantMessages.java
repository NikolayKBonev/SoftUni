package furnitureFactory.common;

public class ConstantMessages {


    public static final String SUCCESSFULLY_BUILD_FACTORY_TYPE = "Successfully build %s %s.";
    public static final String SUCCESSFULLY_BUILD_WORKSHOP_TYPE = "Successfully build workshop of type %s.";
    public static final String SUCCESSFULLY_ADDED_WORKSHOP_IN_FACTORY = "Successfully added workshop of type %s in %s.";
    public static final String SUCCESSFULLY_BOUGHT_WOOD_FOR_FACTORY = "Successfully bought %s.";
    public static final String SUCCESSFULLY_ADDED_WOOD_IN_WORKSHOP = "Successfully added %s to %s.";
    public static final String SUCCESSFUL_PRODUCTION = "%d piece of furniture was produced in the %s factory.";
}
