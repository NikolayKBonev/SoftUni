package furnitureFactory.entities.factories;

public class AdvancedFactory extends BaseFactory {
    public AdvancedFactory(String name) {
        super(name);
    }
}
