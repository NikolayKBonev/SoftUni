package goldDigger.models.discoverer;

public class Archaeologist extends BaseDiscoverer {
    public Archaeologist(String name) {
        super(name, 60);
    }
}
