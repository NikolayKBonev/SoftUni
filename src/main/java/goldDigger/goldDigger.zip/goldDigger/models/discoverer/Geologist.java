package goldDigger.models.discoverer;

public class Geologist extends BaseDiscoverer {
    public Geologist(String name) {
        super(name, 100);
    }
}
